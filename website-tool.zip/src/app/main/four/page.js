import { MainGamepad } from "@/components/MainGamepad/MainGamepad";

export default function HomePage() {

  return (
    <MainGamepad playerNumber={3} />
  );
}
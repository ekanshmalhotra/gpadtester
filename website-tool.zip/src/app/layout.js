import Navbar from "@/components/Navbar/Navbar";
import "./globals.css";

export const metadata = {
  title: "Free Online Gamepad Tester – Check PS5, Xbox & More",
  description: "Gamepad Tester is a free online tool to test buttons, joysticks, and input lag on PS5, Xbox, and PC controllers—no downloads needed.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <meta charSet="UTF-8" />
        <link rel="icon" type="image/svg+xml" href="/favicon.ico" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="google-site-verification" content="ewOW-hExi2QpgK3QJXBosdOy4Q2TggFKBqp88NSDn_8" />
        <title>Free Online Gamepad Tester – Check PS5, Xbox & More</title>
      </head>
      <body>
        <div id="root">
          <Navbar />
          {children}
        </div>
      </body>
    </html>
  );
}
import Navbar from "@/components/Navbar/Navbar";
import "./globals.css";

export const metadata = {
  title: "Gamepad Tester",
  description: "Test your gamepad online using real-time diagnostics and joystick tracking.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <meta charSet="UTF-8" />
        <link rel="icon" type="image/svg+xml" href="/favicon.ico" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>GamePad Tester</title>
      </head>
      <body>
        <div id="root">
          <Navbar />
          {children}
        </div>
      </body>
    </html>
  );
}
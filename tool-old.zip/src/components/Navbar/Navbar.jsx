'use client';

import { useEffect, useState } from 'react';
import { GrGamepad } from 'react-icons/gr';
import { FaHome, FaGamepad, FaTools, FaQuestionCircle } from 'react-icons/fa';
import styles from './Navbar.module.css';
import ScrollToTop from '../ScrollToTop/ScrollToTop';

export default function Navbar() {
  const [activeSection, setActiveSection] = useState('');

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'tester', 'info', 'faq'];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const offsetTop = element.offsetTop;
          const offsetHeight = element.offsetHeight;

          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Call once to set initial state

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  };

  return (
    <>
      <ScrollToTop />
      <nav className={styles.nav}>
        <div className={styles.logoBox}>
          <GrGamepad className={styles.logoIcon} />
          <button
            onClick={() => scrollToSection('home')}
            className={styles.logoText}
          >
            GamePad Tester
          </button>
        </div>
        <ul className={styles.links}>
          {/* <li>
          <button 
            onClick={() => scrollToSection('home')}
            className={activeSection === 'home' ? styles.active : ''}
          >
            <FaHome className={styles.icon} />
            <span>Home</span>
          </button>
        </li> */}
          <li>
            <button
              onClick={() => scrollToSection('tester')}
              className={activeSection === 'tester' ? styles.active : ''}
            >
              <FaGamepad className={styles.icon} />
              <span>Tester</span>
            </button>
          </li>
          <li>
            <button
              onClick={() => scrollToSection('info')}
              className={activeSection === 'info' ? styles.active : ''}
            >
              <FaTools className={styles.icon} />
              <span>Guide</span>
            </button>
          </li>
          <li>
            <button
              onClick={() => scrollToSection('faq')}
              className={activeSection === 'faq' ? styles.active : ''}
            >
              <FaQuestionCircle className={styles.icon} />
              <span>FAQ</span>
            </button>
          </li>
        </ul>
      </nav>
    </>
  );
}
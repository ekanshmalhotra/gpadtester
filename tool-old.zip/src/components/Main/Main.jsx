'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { FaGamepad, FaCheckCircle, FaTimesCircle } from 'react-icons/fa';
import styles from './Main.module.css';

export default function Main() {
  const pathname = usePathname();
  const [connections, setConnections] = useState([false, false, false, false]);

  useEffect(() => {
    const interval = setInterval(() => {
      const pads = navigator.getGamepads();
      setConnections([
        pads[0]?.connected || false,
        pads[1]?.connected || false,
        pads[2]?.connected || false,
        pads[3]?.connected || false
      ]);
    }, 200);

    return () => clearInterval(interval);
  }, []);

  const routes = [
    { path: '/main/one', label: 'Player 1', index: 0 },
    { path: '/main/two', label: 'Player 2', index: 1 },
    { path: '/main/three', label: 'Player 3', index: 2 },
    { path: '/main/four', label: 'Player 4', index: 3 }
  ];

  return (
    <nav className={styles.gamepadNav} id='tester'>
      <ul className={styles.navList}>
        {routes.map((route) => {
          const isActive = pathname === route.path;
          const isConnected = connections[route.index];
          
          return (
            <li key={route.path}>
              <Link href={route.path} className={styles.navLink}>
                <div className={`${styles.navButton} ${isActive ? styles.active : ''} ${isConnected ? styles.connected : ''}`}>
                  <FaGamepad className={styles.gamepadIcon} />
                  <span className={styles.label}>{route.label}</span>
                  <div className={styles.status}>
                    {isConnected ? (
                      <FaCheckCircle className={styles.statusConnected} />
                    ) : (
                      <FaTimesCircle className={styles.statusDisconnected} />
                    )}
                  </div>
                </div>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}